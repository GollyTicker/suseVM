#!/bin/sh
bash ./uninstall.sh
bash ./install.sh
bash ./test.sh