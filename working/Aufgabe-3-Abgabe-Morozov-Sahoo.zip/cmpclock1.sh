#!/bin/bash

diff logfile.txt logs/clock1.txt
