#!/bin/bash

diff logfile.txt logs/fifo.txt
