#!/bin/bash

diff logfile.txt logs/clock2.txt
