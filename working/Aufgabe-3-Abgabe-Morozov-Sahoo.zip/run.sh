#!/bin/bash

make clean
make all
./mmanage

echo "process finished!"
